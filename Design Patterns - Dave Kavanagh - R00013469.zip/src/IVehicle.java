
public interface IVehicle  {

	public void build();
	
	public void ready();
	
	public void setStatus();
	
}
