
public interface MyObserver {
	public void update (MyObservable o) ;
}
