
public interface IVehicleFactory {
	
	public IVehicle buildVehicle();

}
